import { useState } from "react";
import axios from "axios";

export default function App() {
  const [description, setDescription] = useState("");
  const [adScript, setAdScript] = useState("");
  const [videoUrl, setVideoUrl] = useState("");
  const [loading, setLoading] = useState(false);

  const generateAd = async () => {
    setLoading(true);
    setVideoUrl("");
    const { data } = await axios.post("/api/generate-ad", { description });
    setAdScript(data.adScript);
    setLoading(false);
  };

  const generateVideo = async () => {
    setLoading(true);
    const { data } = await axios.post("/api/generate-video", { script: adScript });
    setVideoUrl(data.videoUrl);
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-black to-gray-900 text-white flex flex-col items-center">
      <h1 className="text-5xl font-bold mt-12 mb-6">🎯 AdGeniusAI</h1>
      <p className="text-gray-400 mb-8">AI-powered ad script & video generation in seconds.</p>

      <textarea
        className="w-3/4 md:w-1/2 p-4 rounded-xl text-black focus:outline-none"
        placeholder="Describe your product or service..."
        value={description}
        onChange={(e) => setDescription(e.target.value)}
      />

      <button
        onClick={generateAd}
        disabled={loading}
        className="mt-4 bg-indigo-600 hover:bg-indigo-700 px-6 py-3 rounded-lg font-semibold transition"
      >
        {loading ? "Generating..." : "Generate Ad Script"}
      </button>

      {adScript && (
        <div className="bg-gray-800 p-6 rounded-lg shadow-lg mt-6 w-3/4 md:w-1/2">
          <h2 className="text-2xl font-semibold mb-2">Your AI Ad Script:</h2>
          <p className="text-gray-300 whitespace-pre-line">{adScript}</p>

          <button
            onClick={generateVideo}
            className="mt-4 bg-green-500 hover:bg-green-600 px-5 py-2 rounded-lg text-white font-medium"
          >
            Generate Video 🎬
          </button>
        </div>
      )}

      {videoUrl && (
        <div className="mt-8 w-3/4 md:w-1/2">
          <video controls className="rounded-xl w-full">
            <source src={videoUrl} type="video/mp4" />
          </video>
        </div>
      )}
    </div>
  );
}
