import express from "express";
import cors from "cors";
import axios from "axios";
import Replicate from "replicate";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const REPLICATE_API_TOKEN = process.env.REPLICATE_API_TOKEN;

app.get("/", (req, res) => {
  res.send("🚀 AdGeniusAI backend is running!");
});

app.post("/api/generate-ad", async (req, res) => {
  try {
    const { description } = req.body;
    if (!description) {
      return res.status(400).json({ error: "Missing description" });
    }

    const response = await axios.post(
      "https://api.openai.com/v1/chat/completions",
      {
        model: "gpt-4o-mini",
        messages: [
          {
            role: "system",
            content:
              "You are AdGeniusAI, a creative ad assistant that writes high-converting ad scripts.",
          },
          {
            role: "user",
            content: `Write a 15-second social media ad for: ${description}`,
          },
        ],
      },
      {
        headers: {
          Authorization: `Bearer ${OPENAI_API_KEY}`,
          "Content-Type": "application/json",
        },
      }
    );

    const adScript = response.data.choices[0].message.content;
    res.json({ success: true, adScript });
  } catch (error) {
    console.error("Ad generation error:", error.message);
    res.status(500).json({ error: "Failed to generate ad" });
  }
});

app.post("/api/generate-video", async (req, res) => {
  try {
    const { script, duration } = req.body;
    if (!script)
      return res.status(400).json({ error: "Missing script text" });

    const replicate = new Replicate({
      auth: REPLICATE_API_TOKEN,
    });

    const videoDuration = duration || 5;
    console.log(`Starting ${videoDuration}-second video generation...`);

    const prediction = await replicate.predictions.create({
      model: "wavespeedai/wan-2.1-t2v-480p",
      input: {
        prompt: `Create a cinematic marketing video: ${script}. Smooth camera movement, clean visuals.`,
        duration: videoDuration,
      },
    });

    let completedPrediction = prediction;
    while (
      completedPrediction.status !== "succeeded" &&
      completedPrediction.status !== "failed"
    ) {
      await new Promise((resolve) => setTimeout(resolve, 1500));
      completedPrediction = await replicate.predictions.get(prediction.id);
      console.log("Status:", completedPrediction.status);
    }

    if (completedPrediction.status === "failed") {
      throw new Error("Video generation failed");
    }

    res.json({
      success: true,
      message: "🎬 Video generated successfully!",
      videoUrl: completedPrediction.output,
    });
  } catch (error) {
    console.error("Video generation error:", error.message);
    res.status(500).json({ error: "Video generation failed" });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, "0.0.0.0", () =>
  console.log(`✅ Server running on port ${PORT}`)
);
